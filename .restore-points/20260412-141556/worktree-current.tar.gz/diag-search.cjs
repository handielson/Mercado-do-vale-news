/**
 * diag-search.cjs
 * Diagnóstico: procura "CSTCS2" e "PI153D" em TODOS os campos da VPS e Supabase
 * para descobrir por que a busca não retorna esses produtos.
 * Uso: node diag-search.cjs
 */
require('dotenv').config({ path: '.env.local' });

const VPS_BASE   = process.env.VITE_VPS_BASE_URL || 'https://api.xiaomipetrolina.com.br';
const SYNC_KEY   = process.env.VITE_VPS_SYNC_KEY;
const SUPA_URL   = process.env.VITE_SUPABASE_URL;
const SUPA_KEY   = process.env.VITE_SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY;

const SEARCH_TERMS = ['PI153D', 'CSTCS2'];

async function fetchAllVps() {
  let all = [], offset = 0;
  while (true) {
    const r = await fetch(`${VPS_BASE}/products?limit=500&offset=${offset}&status=all`, {
      headers: { 'X-Sync-Key': SYNC_KEY }
    });
    const page = await r.json();
    if (!Array.isArray(page) || page.length === 0) break;
    all = all.concat(page);
    if (page.length < 500) break;
    offset += 500;
  }
  return all;
}

async function fetchSupabaseSample() {
  const r = await fetch(`${SUPA_URL}/rest/v1/products?select=id,sku,bling_id,name,model_id,slug&limit=1000`, {
    headers: { apikey: SUPA_KEY, Authorization: `Bearer ${SUPA_KEY}` }
  });
  return await r.json();
}

function searchInProduct(p, term) {
  const t = term.toLowerCase();
  const fields = ['name','sku','ean','model_id','slug','description','brand'];
  const found = fields.filter(f => {
    const v = p[f];
    return v && typeof v === 'string' && v.toLowerCase().includes(t);
  });
  // também busca no JSON de custom_fields/specs
  const jsonFields = ['custom_fields','specs'];
  jsonFields.forEach(f => {
    try {
      const str = typeof p[f] === 'string' ? p[f] : JSON.stringify(p[f] || {});
      if (str.toLowerCase().includes(t)) found.push(f + '(JSON)');
    } catch {}
  });
  return found;
}

async function main() {
  console.log('📡 Carregando produtos VPS e Supabase...');
  const [vps, supa] = await Promise.all([fetchAllVps(), fetchSupabaseSample()]);
  console.log(`VPS: ${vps.length} | Supabase: ${supa.length}\n`);

  for (const term of SEARCH_TERMS) {
    console.log(`════════════════════════════════════`);
    console.log(`🔍 Pesquisando: "${term}"`);
    console.log(`════════════════════════════════════`);

    // VPS
    console.log('\n[VPS]');
    let foundVps = false;
    for (const p of vps) {
      const hits = searchInProduct(p, term);
      if (hits.length > 0) {
        foundVps = true;
        console.log(`  ✅ ENCONTRADO nos campos: [${hits.join(', ')}]`);
        console.log(`     name    : "${p.name?.slice(0, 60)}"`);
        console.log(`     sku     : "${p.sku}"`);
        console.log(`     model_id: "${p.model_id}"`);
        console.log(`     slug    : "${p.slug}"`);
        console.log(`     bling_id: "${p.bling_id}"`);
        console.log(`     id      : "${p.id}"`);
      }
    }
    if (!foundVps) console.log(`  ❌ NÃO encontrado em NENHUM campo de nenhum dos ${vps.length} produtos VPS`);

    // Supabase
    console.log('\n[Supabase]');
    let foundSupa = false;
    for (const p of supa) {
      const hits = searchInProduct(p, term);
      if (hits.length > 0) {
        foundSupa = true;
        console.log(`  ✅ ENCONTRADO nos campos: [${hits.join(', ')}]`);
        console.log(`     name    : "${p.name?.slice(0, 60)}"`);
        console.log(`     sku     : "${p.sku}"`);
        console.log(`     model_id: "${p.model_id}"`);
        console.log(`     slug    : "${p.slug}"`);
        console.log(`     bling_id: "${p.bling_id}"`);
        console.log(`     id      : "${p.id}"`);
      }
    }
    if (!foundSupa) console.log(`  ❌ NÃO encontrado em NENHUM campo de nenhum dos ${supa.length} produtos Supabase`);

    console.log('');
  }

  // Mostrar amostra de SKUs da VPS para entender o padrão
  console.log('════════════════════════════════════');
  console.log('📋 Amostra de 15 SKUs da VPS (para ver o padrão de nomenclatura):');
  vps.filter(p => p.sku).slice(0, 15).forEach(p =>
    console.log(`   sku="${p.sku}" | model_id="${p.model_id || '-'}" | nome="${p.name?.slice(0,40)}"`)
  );
}

main().catch(e => { console.error('❌', e.message); process.exit(1); });
